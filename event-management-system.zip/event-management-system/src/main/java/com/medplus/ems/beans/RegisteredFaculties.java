package com.medplus.ems.beans;

import org.springframework.stereotype.Component;

@Component
public class RegisteredFaculties {
	private String registrationId;
	private String eventId;
	private String profileId;
	private String participantName;
	private String participantEmail;
	private long participantContact;
	private String participantCollege;
	private String registrationDate;
	private double eventAmount;
	private String status;
	
	public String getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getProfileId() {
		return profileId;
	}
	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}
	public String getParticipantName() {
		return participantName;
	}
	public void setParticipantName(String participantName) {
		this.participantName = participantName;
	}
	public String getParticipantEmail() {
		return participantEmail;
	}
	public void setParticipantEmail(String participantEmail) {
		this.participantEmail = participantEmail;
	}
	public long getParticipantContact() {
		return participantContact;
	}
	public void setParticipantContact(long participantContact) {
		this.participantContact = participantContact;
	}
	public String getParticipantCollege() {
		return participantCollege;
	}
	public void setParticipantCollege(String participantCollege) {
		this.participantCollege = participantCollege;
	}
	public String getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}
	public double getEventAmount() {
		return eventAmount;
	}
	public void setEventAmount(double eventAmount) {
		this.eventAmount = eventAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
