package com.medplus.ems.beans;

import org.springframework.stereotype.Component;

@Component
public class Event {
	private String eventid;
	private String eventName;
	private String eventDate;
	private String eventTime;
	private String eventPlace;
	private double eventAmount;
	private String eventDescription;
	private String organizerName;
	private long organizerContact;
	private String organizerMail;
	
	
	public String getEventid() {
		return eventid;
	}
	public void setEventid(String eventid) {
		this.eventid = eventid;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventTime() {
		return eventTime;
	}
	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
	}
	public String getEventPlace() {
		return eventPlace;
	}
	public void setEventPlace(String eventPlace) {
		this.eventPlace = eventPlace;
	}
	public double getEventAmount() {
		return eventAmount;
	}
	public void setEventAmount(double eventAmount) {
		this.eventAmount = eventAmount;
	}
	public String getEventDescription() {
		return eventDescription;
	}
	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}
	public String getOrganizerName() {
		return organizerName;
	}
	public void setOrganizerName(String organizerName) {
		this.organizerName = organizerName;
	}
	public long getOrganizerContact() {
		return organizerContact;
	}
	public void setOrganizerContact(long organizerContact) {
		this.organizerContact = organizerContact;
	}
	public String getOrganizerMail() {
		return organizerMail;
	}
	public void setOrganizerMail(String organizerMail) {
		this.organizerMail = organizerMail;
	}
}
