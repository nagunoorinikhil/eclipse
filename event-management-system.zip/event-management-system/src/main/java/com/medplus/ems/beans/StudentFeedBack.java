package com.medplus.ems.beans;

import org.springframework.stereotype.Component;

@Component
public class StudentFeedBack {
	private String registrationId;
	private String eventId;
	private String profileId;
	private int rating;
	private String favoriteActivity;
	private String appreciation;
	private String suggestions;
	
	public String getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getProfileId() {
		return profileId;
	}
	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getFavoriteActivity() {
		return favoriteActivity;
	}
	public void setFavoriteActivity(String favoriteActivity) {
		this.favoriteActivity = favoriteActivity;
	}
	public String getAppreciation() {
		return appreciation;
	}
	public void setAppreciation(String appreciation) {
		this.appreciation = appreciation;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
}
