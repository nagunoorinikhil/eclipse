package com.medplus.ems.beans;

import org.springframework.stereotype.Component;

@Component
public class Login {
	private String profileId;
	private String password;
	
	public String getProfileId() {
		return profileId;
	}
	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
